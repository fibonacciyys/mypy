def print_lol(the_list,indent=False,times=1):
        for each_item in the_list:
                if isinstance(each_item,list):
                        if indent:
                                for num in range(times):
                                        print("\t",end='')
                        print_lol(each_item,indent,times+1)
                else:
                        print(each_item)
			
