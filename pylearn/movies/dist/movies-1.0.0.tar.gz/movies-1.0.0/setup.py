from distutils.core import setup

setup(
	name='movies',
	version='1.0.0',
	py_modules=['movies'],
	author='YY',
	author_email='1102330475@qq.com',
	url='http://www.headfirstlabs.com',
	description='print of list',
      )